// Lets Render start the game with either "node server.js" or "node server/server.js".
require('../server.js');
